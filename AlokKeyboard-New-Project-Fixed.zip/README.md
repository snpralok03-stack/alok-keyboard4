# Alok Keyboard

A standalone Android keyboard (IME) with a dark QWERTY layout and a custom tool row placed directly ABOVE the suggestion row:
MONO | BANANA | REVERSE | ALTERNATE.

## Build on GitHub using a phone
1. Create a new GitHub repository.
2. Upload the contents of this ZIP (extract it first; upload the files/folders, not the ZIP itself).
3. Open Actions and run **Build Alok Keyboard**.
4. Open the successful run and download artifact **ALOK-KEYBOARD-APK**.
5. Extract the artifact ZIP and install `app-debug.apk`.

## Enable keyboard
1. Open Alok Keyboard app.
2. Tap **1. Enable Alok Keyboard** and enable Alok Keyboard in Android settings.
3. Return and tap **2. Choose Alok Keyboard**.
4. Select Alok Keyboard in the input-method picker.

No overlay permission or Accessibility Service is used.

## Text transformations
- MONO: separates letters with spaces while preserving existing word spaces.
- BANANA: doubles each character and separates the pairs with spaces.
- REVERSE: reverses the selected text, or the last word before the cursor.
- ALTERNATE: alternates uppercase/lowercase letters, starting uppercase.

If text is selected, the tool transforms the selection. If nothing is selected, it transforms the last word immediately before the cursor. Some apps/editors may restrict selected-text operations.

Note: The suggestion strip is a visual placeholder, not predictive text. This is a fresh starter keyboard and may not exactly match every detail of your earlier keyboard screenshot.
