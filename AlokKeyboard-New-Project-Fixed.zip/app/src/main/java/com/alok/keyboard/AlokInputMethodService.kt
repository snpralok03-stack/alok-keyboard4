package com.alok.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlokInputMethodService : InputMethodService() {
    private var caps = false
    private val bg = Color.rgb(29, 33, 37)
    private val keyBg = Color.rgb(54, 60, 66)
    private val toolBg = Color.rgb(48, 91, 145)
    private val textColor = Color.WHITE

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(7))
            setBackgroundColor(bg)
        }

        // Custom tools row: directly ABOVE the suggestion row.
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf("MONO", "BANANA", "REVERSE", "ALTERNATE").forEach { mode ->
            tools.addView(makeButton(mode, toolBg, 11f) { transform(mode) },
                LinearLayout.LayoutParams(0, dp(39), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(4))
                })
        }
        root.addView(tools)

        // Suggestion row placeholder, kept as a distinct row below the tools.
        val suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(43, 48, 54), 0)
        }
        listOf("▦", "suggest", "words", "⌨", "🎙").forEachIndexed { index, label ->
            val tv = TextView(this).apply {
                text = label
                textSize = if (index == 0 || index > 2) 17f else 14f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(dp(5), dp(7), dp(5), dp(7))
            }
            suggestions.addView(tv, LinearLayout.LayoutParams(0, dp(35), if (index == 0) .7f else 1f))
        }
        root.addView(suggestions)

        addRow(root, listOf("1","2","3","4","5","6","7","8","9","0"), 43)
        addRow(root, listOf("q","w","e","r","t","y","u","i","o","p"), 47)
        addRow(root, listOf("a","s","d","f","g","h","j","k","l"), 47, sidePadding = 18)

        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row3.addView(makeButton("⇧", Color.rgb(58, 91, 105), 18f) { caps = !caps; restartInputView() }, keyLp(1.25f, 47))
        listOf("z","x","c","v","b","n","m").forEach { ch ->
            row3.addView(makeButton(label(ch), keyBg, 18f) { type(label(ch)) }, keyLp(1f, 47))
        }
        row3.addView(makeButton("⌫", Color.rgb(58, 91, 105), 18f) { delete() }, keyLp(1.25f, 47))
        root.addView(row3)

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bottom.addView(makeButton("?123", Color.rgb(58, 91, 105), 13f) { type("?123") }, keyLp(1.2f, 48))
        bottom.addView(makeButton(",", Color.rgb(58, 91, 105), 18f) { type(",") }, keyLp(.8f, 48))
        bottom.addView(makeButton("☻", keyBg, 18f) { }, keyLp(.9f, 48))
        bottom.addView(makeButton("EN · HG", keyBg, 14f) { type(" ") }, keyLp(3.8f, 48))
        bottom.addView(makeButton(".", Color.rgb(58, 91, 105), 18f) { type(".") }, keyLp(.8f, 48))
        bottom.addView(makeButton("↵", Color.rgb(58, 91, 105), 18f) { enter() }, keyLp(1.2f, 48))
        root.addView(bottom)
        return root
    }

    private fun addRow(root: LinearLayout, keys: List<String>, height: Int, sidePadding: Int = 0) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(sidePadding), 0, dp(sidePadding), 0)
        }
        keys.forEach { key ->
            row.addView(makeButton(label(key), keyBg, 18f) { type(label(key)) }, keyLp(1f, height))
        }
        root.addView(row)
    }

    private fun keyLp(weight: Float, height: Int) =
        LinearLayout.LayoutParams(0, dp(height), weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }

    private fun label(s: String) = if (caps) s.uppercase() else s

    private fun makeButton(title: String, color: Int, size: Float, action: () -> Unit): Button {
        return Button(this).apply {
            text = title
            textSize = size
            isAllCaps = false
            setTextColor(textColor)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(color, dp(7))
            setPadding(dp(1), 0, dp(1), 0)
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { action() }
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun type(value: String) {
        currentInputConnection?.commitText(value, 1)
        if (value.length == 1 && value[0].isLetter()) caps = false
    }

    private fun delete() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun transform(mode: String) {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)?.toString()
        val source: String
        if (!selected.isNullOrEmpty()) {
            source = selected
        } else {
            val before = ic.getTextBeforeCursor(250, 0)?.toString().orEmpty()
            val word = Regex("""\S+$""").find(before)?.value ?: return
            source = word
            ic.deleteSurroundingText(word.length, 0)
        }

        val result = when (mode) {
            "MONO" -> Regex("""\\S+|\\s+""").findAll(source).joinToString("") { match ->
                val token = match.value
                if (token.all { it.isWhitespace() }) token else token.toCharArray().joinToString(" ")
            }
            "BANANA" -> Regex("""\\S+|\\s+""").findAll(source).joinToString("") { match ->
                val token = match.value
                if (token.all { it.isWhitespace() }) token else token.toCharArray().joinToString(" ") { "$it$it" }
            }
            "REVERSE" -> source.reversed()
            "ALTERNATE" -> {
                var letterIndex = 0
                source.map { c ->
                    if (!c.isLetter()) c else {
                        val out = if (letterIndex % 2 == 0) c.uppercaseChar() else c.lowercaseChar()
                        letterIndex++
                        out
                    }
                }.joinToString("")
            }
            else -> source
        }
        ic.commitText(result, 1)
    }

    private fun restartInputView() {
        // Recreate the view so shift state is reflected without any overlay or accessibility service.
        setInputView(onCreateInputView())
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
