package com.alok.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(25, 28, 33))
        }
        val title = TextView(this).apply {
            text = "ALOK KEYBOARD"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Your keyboard stays dark and familiar. MONO, BANANA, REVERSE and ALTERNATE appear in a tool row directly above the suggestion row."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val enable = Button(this).apply {
            text = "1. Enable Alok Keyboard"
            setOnClickListener { startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS")) }
        }
        val choose = Button(this).apply {
            text = "2. Choose Alok Keyboard"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        root.addView(title)
        root.addView(desc)
        root.addView(enable)
        root.addView(choose)
        setContentView(root)
    }
}
